﻿using Abc.Data.Common;

namespace Abc.Data.Money
{
    class CurrencyData : DefinedEntityData
    {
    }
}
