﻿namespace Abc.Data.Common
{
    public class DefinedEntityData : NamedEntityData
    {
        public string Definition { get; set; }
    }

    

    

    
}
